import math
import unittest
from unittest import mock

from tools.retopo_engine import Mesh, RetopoSettings, differential, engine


def assert_manifold_connectors_preserved(test, mesh, result):
    incidence = {}
    for face_index, face in enumerate(mesh.faces):
        for corner, vertex in enumerate(face):
            edge = Mesh.edge_key(vertex, face[(corner + 1) % len(face)])
            incidence.setdefault(edge, []).append((face_index, corner))
    for edge, faces in incidence.items():
        if len(faces) != 2 or edge in engine.non_manifold_edges(mesh):
            continue
        descendants = []
        for face_index, corner in faces:
            face = result.faces[face_index]
            descendants.append(Mesh.edge_key(face[corner], face[(corner + 1) % len(face)]))
        test.assertEqual(descendants[0], descendants[1], edge)


class ContractRegressionTests(unittest.TestCase):
    def test_weld_preserves_faces_and_never_duplicates_a_corner(self):
        result = engine.flatten_to_patterns(differential.curved_grid(), simplify=True, merge_distance=0.01)
        self.assertEqual(9, len(result.vertices))
        self.assertEqual(4, len(result.faces))
        self.assertTrue(all(len(set(face)) >= 3 for face in result.faces))
        welded = engine.weld(differential.unit_guide(), 0.5)
        self.assertEqual(1, len(welded.faces))
        self.assertTrue(all(len(set(face)) >= 3 for face in welded.faces))

    def test_initialization_orders_corners_around_the_boundary(self):
        for source in (differential.hexagon(),):
            result = engine.initialize_planes(source, RetopoSettings())
            self.assertEqual(1, len(result.faces))
            self.assertGreater(abs(engine.signed_area(result.faces[0], result.vertices)), 0.01)

    def test_ring_initialization_preserves_hole_with_non_quad_inputs(self):
        source = differential.ring_guide()
        source.faces = [face[:3] for face in source.faces]
        result = engine.initialize_planes(source, RetopoSettings())
        self.assertTrue(all(len(face) == 4 for face in result.faces))
        self.assertEqual(16, len(result.boundary_edges()))

    def test_initialization_keeps_disconnected_triangulated_patterns_separate(self):
        source = Mesh(
            vertices=[
                (0, 0, 0), (1, 0, 0), (0, 1, 0),
                (3, 0, 0), (4, 0, 0), (3, 1, 0),
            ],
            faces=[(0, 1, 2), (3, 4, 5)],
        )
        result = engine.initialize_planes(source, RetopoSettings())
        self.assertEqual(2, len(result.connected_components()))
        self.assertTrue(all(len(face) == 4 for face in result.faces))

    def test_seam_merge_joins_distinct_uv_islands_and_preserves_bevel_weight(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (0, 0, 0), (2, 0, 0), (2, 2, 0), (0, 2, 0), (0, 4, 0), (2, 4, 0)],
            faces=[(0, 2, 3, 4), (1, 4, 5, 6)],
            uv=[(0, 0), (1, 0), (1, 1), (0, 1), (0, 0), (0, 1), (0, 2), (1, 2)],
        )
        merged = engine.merge_output_seams(mesh, 0.5)
        self.assertLess(len(merged.vertices), 7)
        mesh.edge_attributes["bevel_weight_edge"] = {(0, 1): 1.0}
        protected = engine.merge_output_seams(mesh, 0.5)
        self.assertEqual(7, len(protected.vertices))

    def test_thickness_preserves_metadata_uv_and_outward_winding(self):
        guide = differential.unit_guide()
        guide.uv = [(0, 0), (1, 0), (1, 1), (0, 1)]
        guide.attributes["pattern_id"] = [2]
        guide.attributes["part_id"] = [3]
        guide.attributes["retopo_plane_id"] = [4]
        result = engine.thicken(guide, 0.05, 0.0)
        self.assertEqual([2] * 6, result.attributes["pattern_id"])
        self.assertEqual([3] * 6, result.attributes["part_id"])
        self.assertEqual([4] * 6, result.attributes["retopo_plane_id"])
        self.assertEqual(list(reversed(guide.uv)) + guide.uv, result.uv[:8])
        self.assertEqual([-0.025] * 4 + [0.025] * 4, [vertex[2] for vertex in result.vertices])
        self.assertEqual(6, len(result.faces))
        self.assertTrue(all(len(face) == 4 for face in result.faces))

    def test_smooth_lowpoly_relaxes_3d_without_requiring_uv_smoothing(self):
        guide = Mesh(
            vertices=[(x * 0.5, y * 0.5, 0.0) for y in range(3) for x in range(3)],
            faces=[(0, 1, 4, 3), (1, 2, 5, 4), (3, 4, 7, 6), (4, 5, 8, 7)],
        )
        guide.vertices[4] = (0.4, 0.4, 0.0)
        settings = RetopoSettings(smooth_low_poly=1, smooth_uvs=False, fit_uv=False)
        relaxed = engine.retopologize(differential.curved_grid(), guide, settings)
        settings.smooth_low_poly = 0
        unrelaxed = engine.retopologize(differential.curved_grid(), guide, settings)
        self.assertEqual(relaxed.uv, unrelaxed.uv)
        self.assertNotEqual(relaxed.vertices, unrelaxed.vertices)

    def test_sharp_threshold_changes_density(self):
        guide = differential.two_guide()
        guide.edge_attributes["sharp_edge"] = {(0, 1): True}
        low = engine.apply_density(guide, RetopoSettings(base_density=100, density_add_threshold=0.1))
        high = engine.apply_density(guide, RetopoSettings(base_density=100, density_add_threshold=0.9))
        self.assertNotEqual(len(low.faces), len(high.faces))

    def test_reference_validity_exceptions_produce_usable_geometry(self):
        flat = engine.flatten_to_patterns(differential.curved_grid())
        initialized = engine.initialize_planes(flat, RetopoSettings())
        self.assertGreater(abs(engine.signed_area(initialized.faces[0], initialized.vertices)), 0.5)
        mirrored = engine.mirror_guides(differential.unit_guide(), axes=("y",))
        self.assertTrue(all(engine.signed_area(face, mirrored.vertices) > 0 for face in mirrored.faces))
        shell = engine.thicken(differential.unit_guide(), -0.05)
        volume = 0.0
        for face in shell.faces:
            first, second, third = (shell.vertices[index] for index in face[:3])
            volume += sum(a * b for a, b in zip(first, engine.cross(second, third))) / 6
        self.assertGreater(volume, 0)

    def test_density_reconciliation_is_independent_of_face_order(self):
        vertices = [(x, y, 0) for y in range(4) for x in (0, 1)]
        faces = [(0, 1, 3, 2), (2, 3, 5, 4), (4, 5, 7, 6)]
        guide = Mesh(vertices=vertices, faces=faces)
        guide.edge_attributes["crease_edge"] = {(0, 1): 0.5}
        settings = RetopoSettings(base_density=40, auto_density=False)
        expected = engine.density_edge_counts(guide, settings)
        reversed_guide = Mesh(vertices=vertices, faces=list(reversed(faces)))
        reversed_guide.edge_attributes["crease_edge"] = {(0, 1): 0.5}
        actual = engine.density_edge_counts(reversed_guide, settings)
        self.assertEqual(expected, actual)
        self.assertTrue(all(actual[edge] == 4 for edge in ((0, 1), (2, 3), (4, 5), (6, 7))))

    def test_self_mirror_uses_pattern_center_and_avoids_duplicate_faces(self):
        guide = Mesh(
            vertices=[(0.6, 0.65, 0), (0.8, 0.65, 0), (0.8, 1, 0), (0.6, 1, 0)],
            faces=[(0, 1, 2, 3)],
        )
        mirrored = engine.mirror_guides(guide, axes=("x",), source=differential.mirror_source())
        self.assertEqual(2, len(mirrored.faces))
        self.assertEqual(2, len({tuple(sorted(mirrored.vertices[index] for index in face)) for face in mirrored.faces}))
        full = engine.mirror_guides(differential.mirror_guide(extra_points=0), axes=("x",), source=differential.mirror_source())
        self.assertEqual(1, len(full.faces))
        partial = Mesh(
            vertices=[(0.6, 0.65, 0), (0.7, 0.65, 0), (0.9, 0.65, 0), (0.9, 1, 0), (0.7, 1, 0), (0.6, 1, 0)],
            faces=[(0, 1, 4, 5), (1, 2, 3, 4)],
        )
        mirrored = engine.mirror_guides(partial, axes=("x",), source=differential.mirror_source())
        self.assertEqual(3, len(mirrored.faces))
        signatures = {
            tuple(sorted(tuple(round(value, 8) for value in mirrored.vertices[index]) for index in face))
            for face in mirrored.faces
        }
        self.assertEqual(3, len(signatures))

    def test_dense_seam_merge_does_not_collapse_output_faces(self):
        source = differential.curved_grid()
        source.vertices = [tuple(value * 0.08 for value in vertex) for vertex in source.vertices]
        result = engine.retopologize(
            source, differential.unit_guide(), RetopoSettings(subdiv_reproject=5, fit_uv=False)
        )
        self.assertEqual(1024, len(result.faces))
        self.assertTrue(all(len(face) == 4 for face in result.faces))

    def test_separation_uses_face_attributes_after_seam_merge(self):
        source = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (1, 0, 0), (2, 0, 0), (2, 1, 0), (1, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
            uv=[(0, 0), (0.4, 0), (0.4, 1), (0, 1), (0.6, 0), (1, 0), (1, 1), (0.6, 1)],
        )
        guide = Mesh(
            vertices=[
                (0, 0, 0), (0.4, 0, 0), (0.4, 1, 0), (0, 1, 0),
                (0.1, 0.5, 0), (0.1002, 0.5, 0), (0.1002, 0.5002, 0), (0.1, 0.5002, 0),
                (0.6, 0, 0), (1, 0, 0), (1, 1, 0), (0.6, 1, 0),
            ],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7), (8, 9, 10, 11)],
        )
        result = engine.retopologize(
            source, guide,
            RetopoSettings(fit_uv=False, separate_parts=True, separate_patterns=False),
        )
        self.assertEqual(3, len(result.connected_components()))
        self.assertEqual([0, 0, 1], result.attributes["part_id"])

    def test_bevel_weight_protection_survives_subdivision(self):
        source = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (1, 0, 0), (2, 0, 0), (2, 1, 0), (1, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
            uv=[(0, 0), (0.4, 0), (0.4, 1), (0, 1), (0.6, 0), (1, 0), (1, 1), (0.6, 1)],
        )
        guide = Mesh(
            vertices=[(0, 0, 0), (0.4, 0, 0), (0.4, 1, 0), (0, 1, 0), (0.6, 0, 0), (1, 0, 0), (1, 1, 0), (0.6, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
        )
        guide.edge_attributes["bevel_weight_edge"] = {(1, 2): 1.0, (4, 7): 1.0}
        result = engine.retopologize(
            source, guide,
            RetopoSettings(subdiv_reproject=1, fit_uv=False, separate_patterns=False, separate_parts=False),
        )
        self.assertEqual(2, len(result.connected_components()))
        self.assertTrue(all(len(set(face)) >= 3 for face in result.faces))

    def test_split_edge_repair_preserves_unaffected_face_fans(self):
        mesh = Mesh(
            vertices=[(x, y, 0) for y in range(3) for x in range(3)] + [(1, 0, 1), (0, 0, 1)],
            faces=[(0, 1, 4, 3), (1, 2, 5, 4), (3, 4, 7, 6), (4, 5, 8, 7), (4, 1, 9, 10)],
        )
        result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([(1, 4)], bad_edges)
        self.assertEqual([], engine.non_manifold_edges(result))
        incidence = sum(
            Mesh.edge_key(face[index], face[(index + 1) % len(face)]) == (4, 5)
            for face in result.faces for index in range(len(face))
        )
        self.assertEqual(2, incidence)

    def test_split_edge_repair_keeps_each_split_fan_connected(self):
        mesh = Mesh(
            vertices=[(index, 0, 0) for index in range(12)],
            faces=[(0, 1, 3, 2), (1, 0, 4, 5), (0, 2, 10, 4), (0, 1, 7, 6), (1, 0, 8, 9), (0, 6, 11, 8), (6, 7, 8, 9)],
        )
        mesh.edge_attributes["crease_edge"] = {edge: 0.5 for edge in mesh.edges()}
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(set(range(len(result.vertices))), {index for face in result.faces for index in face})
        self.assertTrue(set(result.edge_attributes["crease_edge"]) <= set(result.edges()))
        for first, second in ((3, 4), (3, 5), (4, 5)):
            first_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[first],) for index in range(4)}
            second_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[second],) for index in range(4)}
            if (first, second) == (3, 4):
                self.assertTrue(set(result.faces[first]) & set(result.faces[second]), (first, second))
            else:
                self.assertTrue(first_edges & second_edges, (first, second))

    def test_split_edge_repair_keeps_single_incident_sheets_connected(self):
        mesh = Mesh(
            vertices=[(index, 0, 0) for index in range(14)],
            faces=[(0, 1, 2, 3), (0, 3, 4, 5), (1, 0, 6, 7), (0, 6, 8, 9), (0, 1, 10, 11), (0, 11, 12, 13)],
        )
        mesh.edge_attributes["crease_edge"] = {edge: 0.5 for edge in mesh.edges()}
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual([0, 1], [index for index, face in enumerate(result.faces) if 0 in face])
        self.assertTrue(set(result.edge_attributes["crease_edge"]) <= set(result.edges()))
        for first, second in ((0, 1), (2, 3), (4, 5)):
            first_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[first],) for index in range(4)}
            second_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[second],) for index in range(4)}
            self.assertTrue(first_edges & second_edges, (first, second))

    def test_non_preserved_multi_face_fans_keep_their_connectors(self):
        mesh = Mesh(
            vertices=[(index, 0, 0) for index in range(18)],
            faces=[(0, 1, 2, 3), (0, 1, 4, 5), (0, 1, 6, 7), (0, 3, 8, 5), (1, 4, 9, 6), (0, 1, 10, 11), (0, 1, 12, 13), (0, 1, 14, 15), (0, 11, 16, 13), (1, 12, 17, 14)],
        )
        mesh.edge_attributes["crease_edge"] = {edge: 0.5 for edge in mesh.edges()}
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(set(range(len(result.vertices))), {index for face in result.faces for index in face})
        self.assertTrue(set(result.edge_attributes["crease_edge"]) <= set(result.edges()))
        for first, second in ((5, 8), (6, 8), (6, 9), (7, 9)):
            self.assertNotEqual(result.faces[first], result.faces[second])
            first_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[first],) for index in range(4)}
            second_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[second],) for index in range(4)}
            original_shared_edges = set(mesh.edges()) & {
                Mesh.edge_key(mesh.faces[first][index], mesh.faces[first][(index + 1) % 4])
                for index in range(4)
            } & {
                Mesh.edge_key(mesh.faces[second][index], mesh.faces[second][(index + 1) % 4])
                for index in range(4)
            }
            if original_shared_edges:
                self.assertTrue(first_edges & second_edges, (first, second))
            else:
                self.assertTrue(set(result.faces[first]) & set(result.faces[second]), (first, second))

    def test_split_edge_repair_splits_even_when_all_fans_are_connected(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, -1, 0)],
            faces=[(0, 1, 2), (1, 0, 3), (0, 1, 4), (0, 2, 3), (1, 3, 4)],
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertNotEqual(mesh.faces, result.faces)

    def test_split_edge_repair_handles_four_connected_faces_without_unused_vertices(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0)] + [(index, 2, 0) for index in range(2, 8)],
            faces=[(0, 1, 3, 2), (1, 0, 2, 4), (0, 1, 4, 5), (1, 0, 5, 6), (4, 5, 7, 6)],
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(set(range(len(result.vertices))), {index for face in result.faces for index in face})

    def test_adjacent_bad_edges_leave_no_unused_vertices(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 1, 1), (0, 1, -1)],
            faces=[(0, 1, 2, 3), (2, 1, 0, 4), (0, 1, 2, 5)],
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(set(range(len(result.vertices))), {index for face in result.faces for index in face})

    def test_triangle_split_preserves_unrelated_valid_sheet(self):
        mesh = Mesh(
            vertices=[
                (0, 0, 0), (1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1),
                (10, 0, 0), (11, 0, 0), (10, 1, 0), (11, 1, 0),
            ],
            faces=[(0, 1, 2), (1, 0, 3), (0, 1, 4), (5, 6, 8), (6, 7, 8)],
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(13, len(result.vertices))
        self.assertEqual(14, len(result.edges()))
        self.assertTrue(set(result.faces[3]) & set(result.faces[4]))

    def test_triangle_components_preserve_internal_manifold_edges(self):
        cases = [
            (
                [(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, -1, 0), (-1, 0, 0)],
                [(0, 1, 2), (1, 0, 3), (0, 1, 4), (0, 2, 3), (0, 2, 5)],
            ),
            (
                [(0, 0, 0), (1, 0, 0), (2, 0, 0), (1, 1, 0), (1, 0, 1), (1, -1, 0)],
                [(0, 1, 3), (1, 2, 3), (1, 0, 4), (2, 1, 4), (0, 1, 5), (1, 2, 5)],
            ),
        ]
        for vertices, faces in cases:
            with self.subTest(faces=faces):
                mesh = Mesh(vertices=vertices, faces=faces)
                result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
                self.assertEqual([], engine.non_manifold_edges(result))
                assert_manifold_connectors_preserved(self, mesh, result)

    def test_retained_face_choice_preserves_connectors_for_every_face_order(self):
        vertices = [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (1, 0, 1), (0, 0, 1), (1, -1, 0), (0, -1, 0), (0, 1, 1), (1, -1, 1)]
        incident = [(0, 1, 2, 3), (0, 1, 4, 5), (0, 1, 6, 7)]
        for order in ((0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0)):
            with self.subTest(order=order):
                faces = [incident[index] for index in order] + [(0, 3, 8, 5), (1, 4, 9, 6)]
                mesh = Mesh(vertices=vertices, faces=faces)
                result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
                self.assertEqual([], engine.non_manifold_edges(result))
                assert_manifold_connectors_preserved(self, mesh, result)

    def test_mixed_fan_repairs_preserve_all_manifold_connectors(self):
        cases = [
            (
                [(index, 0, 0) for index in range(6)],
                [(1, 0, 4), (5, 2, 0), (1, 0, 5), (1, 0, 2, 3), (1, 3, 4)],
            ),
            (
                [(index, 0, 0) for index in range(6)],
                [(0, 5, 4, 1), (4, 2, 1, 0), (0, 1, 5, 3), (3, 1, 5, 4), (3, 1, 4, 0)],
            ),
        ]
        for vertices, faces in cases:
            with self.subTest(faces=faces):
                mesh = Mesh(vertices=vertices, faces=faces)
                result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
                self.assertEqual([], engine.non_manifold_edges(result))
                assert_manifold_connectors_preserved(self, mesh, result)

    def test_healthy_triangle_mesh_is_unchanged_by_repair(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)],
            faces=[(0, 1, 2), (0, 2, 3)],
        )
        with mock.patch.object(engine, "_part_faces", side_effect=AssertionError("healthy mesh must not scan components")):
            result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], bad_edges)
        self.assertEqual(mesh.vertices, result.vertices)
        self.assertEqual(mesh.faces, result.faces)
        self.assertEqual(1, len(result.connected_components()))

    def test_retained_fan_repairs_preserve_all_manifold_connectors(self):
        cases = [
            (
                [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (1, 0, 1), (0, 0, 1), (1, -1, 0), (0, -1, 0), (0, 1, 1), (1, -1, 1)],
                [(0, 1, 2, 3), (0, 1, 4, 5), (0, 1, 6, 7), (0, 3, 8, 5), (1, 4, 9, 6)],
                [(0, 3), (1, 3), (1, 4), (2, 4)],
            ),
            (
                [(index, 0, 0) for index in range(10)],
                [(0, 1, 2, 3), (1, 0, 4, 5), (0, 1, 6, 7), (0, 3, 8, 7), (1, 2, 9, 5)],
                [(0, 3), (2, 3), (0, 4), (1, 4)],
            ),
        ]
        for vertices, faces, connected_pairs in cases:
            with self.subTest(faces=faces):
                mesh = Mesh(vertices=vertices, faces=faces)
                result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
                self.assertEqual([], engine.non_manifold_edges(result))
                for first, second in connected_pairs:
                    first_edges = {Mesh.edge_key(result.faces[first][index], result.faces[first][(index + 1) % 4]) for index in range(4)}
                    second_edges = {Mesh.edge_key(result.faces[second][index], result.faces[second][(index + 1) % 4]) for index in range(4)}
                    self.assertTrue(first_edges & second_edges, (first, second))

    def test_repair_preserves_original_loose_vertices_and_line_attributes(self):
        mesh = Mesh(
            vertices=[(9, 9, 9), (0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 1, 1), (0, -1, 0)],
            faces=[(1, 2, 3, 4), (2, 1, 5, 6), (1, 2, 4, 6)],
            lines=[(2, 4)],
            attributes={"point_guide": [True] * 7},
            edge_attributes={"crease_edge": {(2, 4): 1.0, (1, 2): 0.5}},
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertIn((9.0, 9.0, 9.0), result.vertices)
        self.assertEqual(len(result.vertices), len(result.attributes["point_guide"]))
        self.assertEqual(1.0, result.edge_attributes["crease_edge"][result.lines[0]])
        self.assertEqual([], engine.non_manifold_edges(result))

    def test_debug_edges_follow_real_descendant_faces(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (-1, 0, 0)],
            faces=[(0, 2, 5), (0, 1, 2), (1, 0, 3), (0, 1, 4)],
        )
        original_bad = engine.non_manifold_edges(mesh)
        result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertTrue(set(bad_edges) <= set(result.edges()))
        self.assertEqual(set(bad_edges), set(result.edge_attributes["bad_mesh"]))
        for original, returned in zip(original_bad, bad_edges):
            self.assertEqual(tuple(mesh.vertices[index] for index in original), tuple(result.vertices[index] for index in returned))

    def test_inspection_without_repair_preserves_loose_data_and_debug_indices(self):
        mesh = Mesh(
            vertices=[(9, 9, 9), (0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 1, 1), (0, -1, 0)],
            faces=[(1, 2, 3, 4), (2, 1, 5, 6), (1, 2, 4, 6)],
            lines=[(2, 4)],
            attributes={"point_guide": [True] * 7},
            edge_attributes={"crease_edge": {(2, 4): 1.0, (1, 2): 0.5}},
        )
        result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=False)
        self.assertEqual(mesh.vertices, result.vertices)
        self.assertEqual(mesh.lines, result.lines)
        self.assertEqual(mesh.attributes["point_guide"], result.attributes["point_guide"])
        self.assertEqual(1.0, result.edge_attributes["crease_edge"][(2, 4)])
        for first, second in bad_edges:
            self.assertEqual((mesh.vertices[first], mesh.vertices[second]), (result.vertices[first], result.vertices[second]))

    def test_adjacent_bad_edges_preserve_shared_sheet_edges(self):
        mesh = Mesh(
            vertices=[(x, y, z) for z in (0, 1, -1) for y in (0, 1) for x in (0, 1, 2)],
            faces=[(0, 1, 4, 3), (1, 2, 5, 4), (0, 1, 7, 6), (1, 2, 8, 7), (0, 1, 10, 9), (1, 2, 11, 10)],
            uv=[(0, 0)] * 24,
        )
        result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        self.assertEqual(len(mesh.faces), len(result.faces))
        self.assertEqual(len(result.uv), sum(len(face) for face in result.faces))
        self.assertEqual(engine.non_manifold_edges(mesh), bad_edges)
        for first, second in ((0, 1), (2, 3), (4, 5)):
            first_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[first],) for index in range(4)}
            second_edges = {Mesh.edge_key(face[index], face[(index + 1) % len(face)]) for face in (result.faces[second],) for index in range(4)}
            self.assertTrue(first_edges & second_edges, (first, second))

    def test_density_does_not_weld_coincident_independent_planes(self):
        guide = Mesh(
            vertices=[(0, 0, 0), (0.5, 0, 0), (0.5, 1, 0), (0, 1, 0), (0.5, 0, 0), (1, 0, 0), (1, 1, 0), (0.5, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
        )
        guide.edge_attributes["bevel_weight_edge"] = {(1, 2): 1.0, (4, 7): 1.0}
        guide.edge_attributes["crease_edge"] = {(0, 1): 0.5}
        result = engine.retopologize(
            differential.curved_grid(), guide,
            RetopoSettings(
                base_density=20, fit_uv=False, separate_parts=False, separate_patterns=False,
                seams_merge_distance=0, snapping_distance=0,
            ),
        )
        self.assertEqual(2, len(result.connected_components()))
        self.assertEqual(2, len(set(result.attributes["retopo_plane_id"])))
        self.assertEqual(2, len(result.edge_attributes["bevel_weight_edge"]))

    def test_morph_preview_tolerates_mirror_control_vertices(self):
        result = engine.morph_preview(
            differential.mirror_source(), differential.mirror_guide(),
            RetopoSettings(morph_2d_3d=0.5, fit_uv=False),
        )
        self.assertTrue(all(math.isfinite(value) for vertex in result.vertices for value in vertex))
        self.assertEqual(2, len(result.faces))

    def test_initialize_planes_uses_marked_manual_corner_points(self):
        guide = Mesh(
            vertices=[(0.1, 0.1, 0), (0.9, 0.1, 0), (0.9, 0.9, 0), (0.1, 0.9, 0)],
            faces=[],
            attributes={"point_guide": [True] * 4},
        )
        result = engine.retopologize(
            differential.curved_grid(), guide,
            RetopoSettings(initialize_planes=True, output_generated_planes=True),
        )
        self.assertEqual(guide.vertices, result.vertices)
        self.assertEqual(1, len(result.faces))

    def test_density_plane_ids_distinguish_unequal_components(self):
        guide = Mesh(
            vertices=[(0, 0, 0), (0.4, 0, 0), (0.4, 1, 0), (0, 1, 0), (0.6, 0, 0), (1, 0, 0), (1, 1, 0), (0.6, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
        )
        guide.edge_attributes["crease_edge"] = {(0, 1): 0.5}
        result = engine.retopologize(
            differential.curved_grid(), guide,
            RetopoSettings(base_density=100, fit_uv=False, separate_parts=False, seams_merge_distance=0),
        )
        components = result.connected_components()
        self.assertEqual([11, 1], [len(component) for component in components])
        self.assertEqual([{0}, {1}], [{result.attributes["retopo_plane_id"][index] for index in component} for component in components])
        cursor = 0
        for face in result.faces:
            for vertex in face:
                u, v = result.uv[cursor]
                expected = (u - 0.5, v - 0.5, 0.2 - 0.2 * (abs(u - 0.5) + abs(v - 0.5)))
                for axis in range(3):
                    self.assertAlmostEqual(expected[axis], result.vertices[vertex][axis], delta=0.00001)
                cursor += 1

    def test_simplification_preserves_remapped_point_guides(self):
        source = differential.curved_grid()
        source.attributes["point_guide"] = [index == 8 for index in range(9)]
        result = engine.flatten_to_patterns(source, simplify=True, merge_distance=0.51)
        self.assertEqual(5, len(result.vertices))
        self.assertEqual(4, result.attributes["source_vertex"].index(8))
        self.assertEqual(4, result.attributes["point_guide"].index(True))

    def test_seam_merge_never_welds_two_corners_of_one_face_to_one_cluster(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (5, 0, 0), (5, -5, 0), (0, -5, 0), (0.1, 0, 0), (0, 0.1, 0), (-5, 5, 0), (5, 5, 0)],
            faces=[(0, 3, 2, 1), (4, 5, 6, 7)],
            uv=[(0, 0)] * 8,
        )
        result = engine.merge_output_seams(mesh, 0.5)
        self.assertTrue(all(len(face) == 4 for face in result.faces))

    def test_triangle_repair_preserves_face_identity_uv_and_metadata(self):
        source_faces = [(0, 1, 2), (1, 0, 3), (0, 1, 4)]
        vertices = [(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1)]
        for order in ((0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0)):
            with self.subTest(order=order):
                faces = [source_faces[index] for index in order]
                uv = [(face * 10 + corner, 0) for face in range(3) for corner in range(3)]
                mesh = Mesh(
                    vertices=vertices,
                    faces=faces,
                    uv=uv,
                    attributes={"pattern_id": [10, 11, 12], "part_id": [20, 21, 22], "retopo_plane_id": [30, 31, 32]},
                    edge_attributes={"crease_edge": {edge: index / 10 for index, edge in enumerate(sorted({Mesh.edge_key(face[i], face[(i + 1) % 3]) for face in faces for i in range(3)}))}},
                )
                result, bad_edges = engine.inspect_topology(mesh, fix_split_edges=True)
                self.assertEqual([], engine.non_manifold_edges(result))
                self.assertTrue(set(bad_edges) <= set(result.edges()))
                for original, returned in zip(engine.non_manifold_edges(mesh), bad_edges):
                    self.assertEqual({mesh.vertices[index] for index in original}, {result.vertices[index] for index in returned})
                for face_index, face in enumerate(mesh.faces):
                    self.assertEqual([mesh.vertices[index] for index in face], [result.vertices[index] for index in result.faces[face_index]])
                    self.assertEqual(mesh.uv[face_index * 3:face_index * 3 + 3], result.uv[face_index * 3:face_index * 3 + 3])
                    for name in ("pattern_id", "part_id", "retopo_plane_id"):
                        self.assertEqual(mesh.attributes[name], result.attributes[name])
                    for corner, vertex in enumerate(face):
                        original_edge = Mesh.edge_key(vertex, face[(corner + 1) % 3])
                        new_face = result.faces[face_index]
                        new_edge = Mesh.edge_key(new_face[corner], new_face[(corner + 1) % 3])
                        self.assertEqual(mesh.edge_attributes["crease_edge"][original_edge], result.edge_attributes["crease_edge"][new_edge])

    def test_face_attributes_follow_auto_fill_and_mirror(self):
        guide = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (2, 0, 0), (2, 1, 0)],
            faces=[(0, 1, 2, 3), (1, 4, 5, 2)],
            attributes={
                "retopo_plane_id": [7, 8],
                "pattern_id": [10, 11],
                "part_id": [20, 21],
                "source_vertex": list(range(6)),
                "point_guide": [True, False, False, False, False, True],
            },
            attribute_domains={
                "retopo_plane_id": "FACE", "pattern_id": "FACE", "part_id": "FACE",
                "source_vertex": "POINT", "point_guide": "POINT",
            },
        )
        filled = engine.auto_fill(guide, [(0.3, 0, 0)], 5)
        self.assertEqual(3, len(filled.faces))
        for name, expected in (("retopo_plane_id", [8, 7, 7]), ("pattern_id", [11, 10, 10]), ("part_id", [21, 20, 20])):
            self.assertEqual(expected, filled.attributes[name])
        self.assertEqual(len(filled.vertices), len(filled.attributes["source_vertex"]))
        self.assertEqual(len(filled.vertices), len(filled.attributes["point_guide"]))
        across_components = engine.auto_fill(guide, [(0.3, 0, 0)], 5, across_patterns=False)
        for name, expected in (("retopo_plane_id", [8, 7, 7]), ("pattern_id", [11, 10, 10]), ("part_id", [21, 20, 20])):
            self.assertEqual(expected, across_components.attributes[name])
        self.assertEqual(len(across_components.vertices), len(across_components.attributes["source_vertex"]))
        mirrored = engine.mirror_guides(guide, axes=("x",))
        self.assertEqual(4, len(mirrored.faces))
        for name, expected in (("retopo_plane_id", [7, 8, 7, 8]), ("pattern_id", [10, 11, 10, 11]), ("part_id", [20, 21, 20, 21])):
            self.assertEqual(expected, mirrored.attributes[name])

    def test_auto_fill_subdivision_preserves_point_and_face_metadata(self):
        guide = differential.unit_guide()
        guide.attributes.update({
            "source_vertex": [10, 20, 30, 40],
            "point_guide": [True, False, False, True],
            "pattern_id": [9],
            "corner_tag": [1, 1, 1, 1],
        })
        guide.attribute_domains.update({"point_guide": "POINT", "pattern_id": "FACE", "corner_tag": "CORNER"})
        result = engine.auto_fill(guide, [(0.5, 0.5, 0)], 1)
        self.assertEqual(9, len(result.vertices))
        self.assertEqual(4, len(result.faces))
        self.assertEqual([10, 20, 30, 40, 10, 10, 20, 30, 10], result.attributes["source_vertex"])
        self.assertEqual([True, False, False, True, False, False, False, False, False], result.attributes["point_guide"])
        self.assertEqual([9] * 4, result.attributes["pattern_id"])
        self.assertNotIn("corner_tag", result.attributes)

    def test_auto_fill_separates_metadata_by_component(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (3, 0, 0), (4, 0, 0), (4, 1, 0), (3, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
            attributes={
                "pattern_id": [100, 200],
                "source_vertex": list(range(8)),
                "point_guide": [False] * 8,
            },
            attribute_domains={"pattern_id": "FACE"},
        )
        result = engine.auto_fill(mesh, [(0.5, 0.5, 0)], 1, across_patterns=False)
        self.assertEqual([100, 100, 100, 100, 200], result.attributes["pattern_id"])
        self.assertEqual([0, 1, 2, 3, 0, 0, 1, 2, 0, 4, 5, 6, 7], result.attributes["source_vertex"])
        self.assertEqual([False] * 13, result.attributes["point_guide"])

    def test_undeclared_known_point_domains_are_consistent(self):
        size = 4
        vertices = [
            ((3 + math.cos(math.tau * i / size) * math.cos(math.tau * j / size), 3 + math.sin(math.tau * i / size) * math.cos(math.tau * j / size), math.sin(math.tau * j / size)))
            for i in range(size) for j in range(size)
        ]
        faces = [
            (i * size + j, ((i + 1) % size) * size + j, ((i + 1) % size) * size + (j + 1) % size, i * size + (j + 1) % size)
            for i in range(size) for j in range(size)
        ]
        guide = Mesh(
            vertices=vertices,
            faces=faces,
            attributes={"source_vertex": list(range(16)), "point_guide": [True] + [False] * 15},
        )
        center = guide.vertices[5]
        filled = engine.auto_fill(guide, [center], 1)
        self.assertEqual(len(filled.vertices), len(filled.attributes["source_vertex"]))
        self.assertEqual(1, sum(filled.attributes["point_guide"]))
        mirrored = engine.mirror_guides(guide, axes=("x",))
        self.assertEqual(len(mirrored.vertices), len(mirrored.attributes["source_vertex"]))
        self.assertEqual(2, sum(mirrored.attributes["point_guide"]))
        subdivided = engine.subdivide_quads(guide)
        self.assertEqual(list(range(16)), subdivided.attributes["source_vertex"][:16])
        self.assertEqual(1, sum(subdivided.attributes["point_guide"]))
        merged = engine.merge_output_seams(filled, 0.01)
        self.assertEqual(len(merged.vertices), len(merged.attributes["source_vertex"]))

    def test_reconstruction_preserves_explicit_attribute_domains(self):
        separated = engine._separate(
            Mesh(
                vertices=[(0, 0, 0), (0.5, 0, 0), (1, 0, 0), (0, 1, 0), (0.5, 1, 0), (1, 1, 0)],
                faces=[(0, 1, 4, 3), (1, 2, 5, 4)],
                uv=[(0, 0), (0.5, 0), (0.5, 1), (0, 1), (0.5, 0), (1, 0), (1, 1), (0.5, 1)],
                attributes={"pattern_id": [0, 1, 2, 3, 4, 5]},
                attribute_domains={"pattern_id": "POINT"},
            ),
            [0, 1],
        )
        self.assertEqual([0, 1, 4, 3, 1, 2, 5, 4], separated.attributes["pattern_id"])
        self.assertEqual("POINT", separated.attribute_domains["pattern_id"])
        merged = engine.merge_output_seams(
            Mesh(
                vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 0, 0), (-1, 0, 0), (-1, -1, 0), (0, -1, 0)],
                faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
                attributes={"source_vertex": list(range(8)), "pattern_id": [10, 20]},
                attribute_domains={"pattern_id": "FACE"},
            ),
            0.01,
        )
        self.assertEqual([0, 1, 2, 3, 5, 6, 7], merged.attributes["source_vertex"])
        self.assertEqual([10, 20], merged.attributes["pattern_id"])
        positions = [(0, 0, 0), (2, 0, 0), (2, 2, 0), (0, 2, 0), (1, 1, 0), (1, 0.3, 0)]
        source_faces = [(0, 1, 5), (1, 4, 5), (4, 0, 5), (1, 2, 4), (2, 3, 4), (3, 0, 4)]
        equal_counts = Mesh(
            vertices=positions + [(-x, -y, z) for x, y, z in positions],
            faces=source_faces + [tuple(index + 6 for index in face) for face in source_faces],
            attributes={"source_vertex": list(range(12))},
        )
        merged_equal = engine.merge_output_seams(equal_counts, 0.01)
        self.assertEqual([0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11], merged_equal.attributes["source_vertex"])
        guide = differential.ring_guide()
        guide.attributes["pattern_id"] = list(range(16))
        guide.attribute_domains["pattern_id"] = "POINT"
        thickened = engine.thicken(guide, 0.1)
        self.assertEqual(list(range(16)) * 2, thickened.attributes["pattern_id"])
        self.assertEqual("POINT", thickened.attribute_domains["pattern_id"])

    def test_mirror_normalizes_loose_line_attribute_keys(self):
        guide = Mesh(
            vertices=[(3, 0, 0), (1, 0, 0), (2, 0, 0), (2, 1, 0), (1, 1, 0)],
            faces=[(1, 2, 3, 4)],
            lines=[(0, 1)],
            edge_attributes={"crease_edge": {(0, 1): 0.7}},
        )
        result = engine.mirror_guides(guide, axes=("x",))
        self.assertTrue(all(edge == Mesh.edge_key(*edge) for edge in result.edge_attributes["crease_edge"]))
        self.assertEqual(2, len(result.edge_attributes["crease_edge"]))

    def test_repair_preserves_face_domains_when_vertex_count_crosses_face_count(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, -1, -1)],
            faces=[(0, 2, 1), (0, 1, 3), (1, 2, 3), (0, 3, 2), (0, 1, 4)],
            uv=[(face * 10 + corner, 0) for face in range(5) for corner in range(3)],
            attributes={
                "pattern_id": [10, 11, 12, 13, 14],
                "part_id": [20, 21, 22, 23, 24],
                "retopo_plane_id": [30, 31, 32, 33, 34],
                "source_vertex": [0, 1, 2, 3, 4],
            },
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        for name in ("pattern_id", "part_id", "retopo_plane_id"):
            self.assertEqual(mesh.attributes[name], result.attributes[name])
        self.assertEqual(len(result.vertices), len(result.attributes["source_vertex"]))
        for face_index, face in enumerate(mesh.faces):
            self.assertEqual(mesh.uv[face_index * 3:face_index * 3 + 3], result.uv[face_index * 3:face_index * 3 + 3])
            self.assertEqual([mesh.vertices[index] for index in face], [result.vertices[index] for index in result.faces[face_index]])

    def test_repair_uses_explicit_attribute_domains(self):
        point_mesh = differential.non_manifold()
        point_mesh.attributes = {"pattern_id": [10, 11, 12, 13, 14], "source_vertex": [0, 1, 2, 3, 4]}
        point_mesh.attribute_domains = {"pattern_id": "POINT", "source_vertex": "POINT"}
        point_result, _ = engine.inspect_topology(point_mesh, fix_split_edges=True)
        self.assertEqual([10, 11, 14, 10, 11, 12, 11, 10, 13], point_result.attributes["pattern_id"])
        self.assertEqual("POINT", point_result.attribute_domains["pattern_id"])
        face_mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, -1, -1)],
            faces=[(0, 2, 1), (0, 1, 3), (1, 2, 3), (0, 3, 2), (0, 1, 4)],
            attributes={
                "pattern_id": [10, 11, 12, 13, 14],
                "part_id": [20, 21, 22, 23, 24],
                "retopo_plane_id": [30, 31, 32, 33, 34],
                "source_position": [(0, 0, 0)] * 5,
            },
            attribute_domains={"pattern_id": "FACE", "part_id": "FACE", "retopo_plane_id": "FACE", "source_position": "POINT"},
        )
        face_result, _ = engine.inspect_topology(face_mesh, fix_split_edges=True)
        for name in ("pattern_id", "part_id", "retopo_plane_id"):
            self.assertEqual(face_mesh.attributes[name], face_result.attributes[name])
            self.assertEqual("FACE", face_result.attribute_domains[name])
        self.assertEqual(len(face_result.vertices), len(face_result.attributes["source_position"]))

    def test_repair_is_canonical_across_face_order(self):
        faces = [(1, 3, 5, 4), (2, 5, 4, 3), (0, 6, 2, 5), (5, 2, 4, 6), (5, 4, 0, 1), (3, 1, 0, 2)]
        vertices = [(index, 0, 0) for index in range(7)]
        first, _ = engine.inspect_topology(Mesh(vertices=vertices, faces=faces), fix_split_edges=True)
        order = (5, 0, 2, 3, 1, 4)
        second, _ = engine.inspect_topology(Mesh(vertices=vertices, faces=[faces[index] for index in order]), fix_split_edges=True)
        self.assertEqual(len(first.vertices), len(second.vertices))
        self.assertEqual(len(first.boundary_edges()), len(second.boundary_edges()))
        assert_manifold_connectors_preserved(self, Mesh(vertices=vertices, faces=faces), first)

    def test_duplicate_triangle_pairs_keep_their_manifold_edges(self):
        mesh = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (0, 1, 0), (1, 1, 0)],
            faces=[(2, 0, 3), (0, 2, 3), (2, 3, 1)],
        )
        result, _ = engine.inspect_topology(mesh, fix_split_edges=True)
        self.assertEqual([], engine.non_manifold_edges(result))
        assert_manifold_connectors_preserved(self, mesh, result)

    def test_mirror_does_not_swap_asymmetric_edge_attributes(self):
        guide = Mesh(
            vertices=[(-1, 0, 0), (1, 0, 0), (1, 1, 0), (-1, 1, 0), (-3, 0, 0), (-3, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 0, 3, 5)],
        )
        guide.edge_attributes["crease_edge"] = {edge: 0.0 for edge in guide.edges()}
        guide.edge_attributes["crease_edge"][(0, 3)] = 0.8
        mirrored = engine.mirror_guides(guide, axes=("x",))
        self.assertEqual(0.8, mirrored.edge_attributes["crease_edge"][(0, 3)])
        self.assertEqual(0.0, mirrored.edge_attributes["crease_edge"][(1, 2)])

    def test_mirror_and_separation_preserve_edge_attributes(self):
        guide = differential.unit_guide()
        guide.edge_attributes["bevel_weight_edge"] = {edge: 1.0 for edge in guide.edges()}
        guide.edge_attributes["crease_edge"] = {edge: 0.8 for edge in guide.edges()}
        guide.attributes["point_guide"] = [True, True, False, True]
        mirrored = engine.mirror_guides(guide, axes=("x",))
        self.assertEqual(len(mirrored.vertices), len(mirrored.attributes["point_guide"]))
        self.assertEqual(4, sum(mirrored.attributes["point_guide"]))
        self.assertTrue(mirrored.attributes["point_guide"][mirrored.vertices.index((-1.0, 0.0, 0.0))])
        self.assertTrue(all(value > 0 for value in mirrored.edge_attributes["bevel_weight_edge"].values()))
        self.assertTrue(all(value > 0 for value in mirrored.edge_attributes["crease_edge"].values()))
        self.assertEqual(7, len(mirrored.edge_attributes["bevel_weight_edge"]))
        self.assertEqual(7, len(mirrored.edge_attributes["crease_edge"]))
        separated = engine.retopologize(
            differential.curved_grid(), guide, RetopoSettings(fit_uv=False, separate_parts=True)
        )
        self.assertEqual(16, len(separated.edge_attributes["bevel_weight_edge"]))
        self.assertTrue(all(value > 0 for value in separated.edge_attributes["bevel_weight_edge"].values()))

    def test_separation_edge_attributes_reference_only_real_group_edges(self):
        mesh = Mesh(
            vertices=[(index, 0, 0) for index in range(13)],
            faces=[(0, 1, 2, 3), (0, 7, 8, 9), (1, 10, 11, 12)],
            uv=[(0, 0)] * 12,
            edge_attributes={"bevel_weight_edge": {(0, 1): 1.0}},
        )
        result = engine._separate(mesh, [0, 1, 1])
        self.assertTrue(set(result.edge_attributes["bevel_weight_edge"]) <= set(result.edges()))

    def test_plane_ids_follow_connected_components(self):
        guide = Mesh(
            vertices=[(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (2, 0, 0), (3, 0, 0), (3, 1, 0), (2, 1, 0)],
            faces=[(0, 1, 2, 3), (4, 5, 6, 7)],
        )
        result = engine.retopologize(differential.curved_grid(), guide, RetopoSettings(fit_uv=False, seams_merge_distance=0))
        self.assertEqual(2, len(result.connected_components()))
        self.assertEqual(2, len(set(result.attributes["retopo_plane_id"])))
        for component in result.connected_components():
            self.assertEqual(1, len({result.attributes["retopo_plane_id"][index] for index in component}))

    def test_empty_guides_are_rejected_without_initialization(self):
        with self.assertRaisesRegex(ValueError, "at least one quad"):
            engine.retopologize(differential.curved_grid(), Mesh(vertices=[], faces=[]))
        report = engine.diagnose(Mesh(vertices=[], faces=[]), RetopoSettings(), differential.curved_grid())
        self.assertEqual("error", report["status"])
        self.assertIn("empty_guide", report["errors"])

    def test_staged_reports_use_output_specific_names(self):
        from pathlib import Path
        from tools.retopo_engine.staging import report_path_for_output

        first = report_path_for_output(Path("staging/first.blend"))
        second = report_path_for_output(Path("staging/second.blend"))
        self.assertNotEqual(first, second)
        self.assertEqual(Path("staging/first-retopo-report.json"), first)

    def test_preview_guides_expose_contacts_polyloops_mismatches_and_density_counts(self):
        guide = differential.two_guide()
        self.assertEqual({(1, 4)}, engine.sibling_contact_edges(guide))
        self.assertEqual(guide.edges(), engine.polyloop_guides(guide).lines)
        guide.edge_attributes["crease_edge"] = {(0, 1): 0.5}
        settings = RetopoSettings(base_density=20)
        self.assertEqual(2, engine.requested_density_counts(guide, settings)[(0, 1)])
        self.assertEqual({(0, 1), (3, 4)}, engine.mismatch_edges(guide, settings))
        counts = engine.density_edge_counts(guide, settings)
        self.assertEqual(2, counts[(0, 1)])
        self.assertEqual(2, counts[(3, 4)])


if __name__ == "__main__":
    unittest.main()
